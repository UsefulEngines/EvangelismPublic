# Week 2 Teacher Guide — Sacrifice Reveals the Good: The Four Layers

*The Obedience of Faith, Week 2 of 12. Companion to `Week02-SacrificeRevealsTheGood.pptx` (7 slides, 25 click-stops). Scripture from the NET Bible.*

**Aim:** Teach the four-layer framework — Religion, Worship, Sacrifice, Obedience of Faith — and show why sacrifice is what makes worship visible.

**What this week must accomplish (and nothing more):** the class leaves able to say the four words *in order* and state each layer's one-word function — form, disposition, cost, pattern. That vocabulary is load-bearing for the next ten weeks; Saul, Uzzah, Malachi, the church's tests, and the living sacrifice all get named by these layers later. If the class memorizes the stack, the week succeeded. Everything else is reinforcement.

**The bridge from Week 1:** last week ended on a deliberately unresolved question — *how does the invisible become visible, and how does a person learn to see it?* This week answers the first half (sacrifice makes it visible). Weeks 5 and 9 answer the second half (the Berean practice trains the seeing). Say this out loud at the recap; a course that visibly keeps its promises earns trust.

---

## Segment 1 — Moriah: What God Asked For (0:00–10:00 · Slide 2)

**The recap click (60 seconds, not more).** Week 1 in three sentences: the Good has a source (Mark 10:18) · its purpose is union (Rom 8:29) · recognizing it is trained by practice (Heb 5:14). Invite the class to say them with you — lightly, no quiz energy. By Week 4 they will beat you to it.

**The text.** Read Genesis 22:2 slowly and point at the escalation the verse itself builds: *your son — your only son — whom you love — Isaac.* Four steps, each closing an escape hatch. Hebrew narrative rarely lingers like this; when it does, the lingering is the message. God is not naming a possession. He is naming the one thing Abraham cannot surrender and still keep his own version of the future.

**The move that connects to Week 1:** God does not ask Abraham to *feel* devoted. Last week established that devotion is invisible, even to its owner — and here, on the first page of the sacrifice story, God acts on exactly that problem. The command is a request for visibility.

**Hebrews' reading (final click).** "By faith Abraham, when he was tested, offered up Isaac… and he reasoned that God could even raise him from the dead" (Heb 11:17, 19). Two things to draw out. First, Abraham's faith had *content* — he reasoned; this was not blind leaping but trust in a promise-keeping God who had said "through Isaac" (Gen 21:12) and would therefore have to resolve the contradiction Himself. Second, the line to land: **faith became visible at the raised knife.** Not in the feeling beforehand — in the act.

**Handle the ethical discomfort before it hardens** (it is in the room whether voiced or not): God stops the knife and provides the ram (22:12–13). The test was for *revealing*, never for taking — "now I know" (22:12) is disclosure language, and the whole Old Testament thereafter condemns child sacrifice in the strongest terms (Jer 32:35). Say this in one or two sentences here; the fuller treatment is in the Q&A section below if discussion demands it.

**Transition:** "Scripture has four words for what happened on that mountain — and they are not synonyms."

## Segment 2 — The Stack (10:00–30:00 · Slide 3)

This slide is the lecture's core: twenty minutes, five per layer, one click each. The stack builds bottom-up — Religion first — and the right-hand notes appear with each layer. Pace by the wall clock, not by feel; layer 1 always runs long and layer 4 always gets robbed.

**Layer 1 — Religion, the FORM (10:00).** James's word is *threskeia* — the outward system: observance, attendance, identity markers, the things a person does in order to count as religious. Note carefully what James does with it: he defines *pure* religion not by its rituals but by its output — orphans, widows, an unstained life (1:27) — and declares the whole thing "futile" when the tongue runs unbridled (1:26). Religion is the container. Scripture never despises the container — but never mistakes it for the contents. *Guard the tone:* "religion" is not a dirty word this week; layer 1 is a real layer, and the course is not "relationship not religion" sloganeering. The form matters; it just proves nothing alone.

**Layer 2 — Worship, the DISPOSITION (15:00).** John 4:23–24 — Jesus relocates worship from geography (this mountain, Jerusalem) to disposition: spirit and truth. This is a decisive elevation — and it creates the problem Week 1 named. Ask the room: *"How would you show me your worship — without doing anything?"* Let the silence do the work. You can't. A disposition is invisible, even to its owner. That is not a flaw in worship; it is why the next layer exists.

**Layer 3 — Sacrifice, the COST (20:00).** Worship's currency — the moment the disposition pays something and becomes an event. Moriah is the paradigm; Romans 12:1 is the transfer to us: "present your bodies as a sacrifice — alive, holy, and pleasing to God." Keep Romans 12 brief — Week 9 lives there — but plant the phrase. The teaching point: costless worship is *indistinguishable* from sentiment, not just weaker than sacrifice. Without cost there is no evidence, even for the worshiper himself.

**Layer 4 — Obedience of Faith, the SETTLED PATTERN (25:00).** Paul's phrase brackets Romans — 1:5 and 16:26 — the same words opening and closing his greatest letter, which is Paul telling us what the whole gospel project is *for*. Not one dramatic act (Abraham had one mountain; he also had a lifetime), but a life reorganized around what it claims: the whole stack holding over time.

**The summary click:** Form → Disposition → Cost → Pattern. Have the class read the four words aloud with you, in order. Do not skip this — saying it together is the memorization mechanism, and it takes ten seconds.

## Segment 3 — Each Layer Without the Next (30:00–40:00 · Slide 4)

The sobering structural fact: each layer can exist without the one above it. Three rows, briskly, then the verdict.

**Religion without worship — the Pharisee.** Honoring with lips while the heart is far away (Isa 29:13; quoted by Jesus in Matt 15:8). The container, empty. One minute.

**Worship without sacrifice — sentiment.** Ezekiel's hearers are the sharpest text nobody knows: they attended faithfully, sat as God's people, *loved* the preaching — God tells Ezekiel he is to them like a beautiful voice singing a sensual song — and they did not act on a word of it (Ezek 33:31–32). Feeling that never lands. **This row convicts modern churchgoing most directly** — the person who is moved every Sunday and changed by none of them. Deliver it in first-person plural ("this is the row that comes for us") — confession opens ears; accusation closes them.

**Sacrifice without obedience — Saul.** Real animals, real altar, real ritual — built on an edited command (1 Sam 15; the class read the fuller account's cousin last week and will read Uzzah next week, so one minute here suffices).

**Samuel's verdict (read slowly):** "Does the Lord take pleasure in burnt offerings and sacrifices as much as he does in obedience? Certainly, obedience is better than sacrifice; paying attention is better than the fat of rams" (1 Sam 15:22). **Immediately guard the misreading:** Samuel is not anti-ritual — God *commanded* sacrifice; Samuel himself offered them. The sin is *substitution*: layer three offered in place of layer four. Ritual as obedience is worship; ritual instead of obedience is rebellion — the verse's next line calls it divination.

**The line, then pause:** "Saul had layer three — and thought it was layer four." That sentence is Week 2's hinge and next week's doorway.

**Transition:** "So what makes an act a sacrifice at all? A North African bishop answered that in one sentence, sixteen centuries ago."

## Segment 4 — Augustine's Definition (40:00–45:00 · Slide 5)

Read the definition twice — it is dense: "A true sacrifice is every work which is done that we may be united to God in holy fellowship, and which has a reference to that supreme good and end in which alone we can be truly blessed" (*City of God* X.6).

Three unpacking moves, one click each:

**"Every work."** Not just altars. Any work aimed at union with God qualifies — which is how Augustine explains why the Old Testament's animal sacrifices were never the point in themselves: they were symbols pointing at the whole-life sacrifice they were meant to produce.

**The corollary — direction decides.** Augustine adds that mercy shown to another, "if it is not shown for God's sake, is not a sacrifice." The identical act — same money, same casserole, same hour of help — is worship in one direction and mere philanthropy in the other. The offering is in where it points. (This quietly answers a question someone is thinking: "so is my volunteering a sacrifice?" Answer: it depends entirely on its direction.)

**Week 1 inside the definition.** "That we may be *united* to God" — union, not admiration; Augustine and Mark 10 are teaching the same lesson. Then the framing sentence: sacrifice is not the *price* of union; it is the *road* union travels — the visible shape of a heart moving toward God.

**The grace anchor (final click, unhurried):** Romans 12:1 begins "by the mercies of God." Mercy first, altar second — say it, remind them it recurs by design, and move to discussion *on time*.

## Segments 5–6 — Discussion and the Close (45:00–57:00 · Slides 6–7)

**Q1 — "Which layer does religious activity most easily counterfeit — and why that one?"** Expect "worship" or "obedience." Collect answers, then offer the strongest one if no one finds it: religion counterfeits *all three* layers above it, because form is the visible layer — activity photographs well. Then the pressing question, once: *"Which counterfeit fools the person himself?"* (That is Saul, and it is next week.)

**Q2 — "Why is a costless faith invisible even to the person who holds it?"** Aim the room at Week 1's thread: without cost there is no evidence — nothing to examine, even in self-examination (2 Cor 13:5). If quiet, seed with: *"What do you know about your own faith only because it cost you something once?"* Invite **one** testimony, not a series — a single concrete story teaches the point better than five, and you have ten minutes.

**The close (slide 7, ~2 min).** Next week's reading with its guiding questions — and note the design: the second question hands them 1 Chronicles 15:13 *in advance*. That is deliberate; a Berean class should arrive already holding David's own explanation, so Week 3's lecture confirms their reading rather than performing a reveal. One-sentence preview of Week 3. The carry sentence — say the four words together one final time. Close on Samuel's verdict and dismiss punctually.

---

## Answers to Questions You May Get

**"How could a good God command child sacrifice — even as a test?"** Take it seriously; do not joke it away. Four anchors: (1) the reader knows from verse 1 what Abraham doesn't — "God *tested* Abraham" — the narrator flags the category before the command; (2) God stops the knife and provides the ram (22:12–13) — the test reveals, it never takes; (3) Scripture elsewhere condemns child sacrifice in the strongest available terms (Jer 32:35; Deut 12:31) — Moriah is not an exception to that but the dramatized *end* of it: God provides the substitute; (4) Hebrews 11:19 shows Abraham's own reasoning — resurrection — meaning he obeyed a promise-keeping God, not a capricious one. If the questioner presses on Abraham's willingness itself, concede honestly that the text means the test to be as heavy as it feels — a test that asked for nothing would reveal nothing.

**"Doesn't 'obedience is better than sacrifice' prove externals don't matter — so why the emphasis on form (layer 1)?"** Samuel's sentence compares a real thing to a counterfeit *use* of it, not ritual to sincerity. God commanded the sacrifices Saul was performing; the fault was substitution, not ceremony. The stack keeps this straight: layer 1 is a genuine layer — it just cannot stand in for layer 4.

**"Is layer 4 works-salvation?"** No — and point at the slide: Romans 12:1 begins "by the mercies of God." The obedience of faith is faith's *shape*, not its price (the course states this at Weeks 4, 7, 9, and 12 by design). Israel was redeemed from Egypt before Sinai, not by it. If the questioner wants the faith-works text itself: James 2:21–22 says Abraham's faith "was working together with his works and his faith was perfected by works" — Moriah *completed* faith that God had already credited in Genesis 15:6, thirty-plus years earlier. The chronology is the answer.

**"Where do baptism and communion fit in the stack?"** Good instinct — hold it. Week 8 places them precisely (entry test and recurring test). For now: they are commanded obediences that function exactly as the stack predicts — visible, costly, covenantal. Deferring with a promised address teaches the class the course has a map.

**"Can someone have layer 3 without layer 2 — sacrifice without worship?"** Yes — and Scripture names it: the Pharisees fasting and tithing "to be seen by people" (Matt 6:1–18) paid real costs aimed at the wrong audience, and 1 Corinthians 13:3 gives the extreme case: surrendering the body without love gains nothing. Cost without Godward disposition is performance. This is why the stack is a *stack* — each layer needs the ones beneath it.

## Prep Checklist

- [ ] Read Genesis 22:1–19 whole, plus Genesis 21:12 and Jeremiah 32:35 (your Moriah-ethics anchors)
- [ ] Read Ezekiel 33:30–33 in full — the "sensual song" context makes the sentiment row land
- [ ] Rehearse slide 3's five clicks against the wall clock: layer 1 ends at 15:00, layer 2 at 20:00, layer 3 at 25:00
- [ ] Decide your one-sentence first-person confession for the Ezekiel row
- [ ] Print or post next week's reading with both guiding questions
- [ ] Confirm animations run On Click (Animation Pane check before class)

## If You Run Long

Cut in this order: the Week 1 recap click to a single spoken sentence; the Isaiah/Matthew row on slide 4 to one clause ("the Pharisee — lips near, heart far"); Augustine's "every work" unpacking to the definition plus corollary only. **Never cut:** the class saying the four words aloud (slide 3's final click), Samuel's verdict read slowly, or the mercy-first click. If discussion must shrink, drop Q1 and keep Q2 — it carries Week 1's thread forward.
